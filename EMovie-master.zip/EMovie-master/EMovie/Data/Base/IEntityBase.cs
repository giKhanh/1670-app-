﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EMovie.Data.Base
{
    public interface IEntityBase
    {
        int ID { get; set; }
    }
}
